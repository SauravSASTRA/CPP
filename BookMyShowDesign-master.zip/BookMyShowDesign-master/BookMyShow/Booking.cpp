#include "stdafx.h"
#include "Booking.h"


Booking::Booking() {
}


Booking::~Booking() {
}
