#pragma once
class Booking {
public:
	Booking();
	virtual ~Booking();
};

