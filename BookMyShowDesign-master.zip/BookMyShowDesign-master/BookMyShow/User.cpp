#include "stdafx.h"
#include "User.h"


User::User() {
}


User::~User() {
}
