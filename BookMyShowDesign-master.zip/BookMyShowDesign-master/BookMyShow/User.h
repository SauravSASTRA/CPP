#pragma once
class User {
public:
	User();
	virtual ~User();
};

