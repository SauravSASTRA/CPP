#include "stdafx.h"
#include "Vehicle.h"

std::string Vehicle::getNumberPlate() const {
	return numberPlate;
}

Vehicle::~Vehicle() {

}